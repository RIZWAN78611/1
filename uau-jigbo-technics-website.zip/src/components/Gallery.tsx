"use client";

import React from "react";
import SectionHeading from "./SectionHeading";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import Lightbox from "./Lightbox";
import { useState } from "react";

const galleryItems = [
  {
    title: "Precision Measurement (±0.010)",
    category: "Quality Control",
    image: "/gallery/precision-measurement.jpg",
  },
  {
    title: "Custom Amaron Battery Mold",
    category: "Molds",
    image: "/gallery/amaron-mold.jpg",
  },
  {
    title: "CNC Machined Aluminum Fins",
    category: "Components",
    image: "/gallery/aluminum-fins.jpg",
  },
  {
    title: "Complex CNC Component",
    category: "Machining",
    image: "/gallery/component-complex.jpg",
  },
  {
    title: "Makino Slim 3 CNC Machine",
    category: "Machinery",
    image: "/gallery/makino-slim3.jpg",
  },
  {
    title: "Injection Mold Detail",
    category: "Molds",
    image: "/gallery/mold-part-1.jpg",
  },
  {
    title: "Vertical Machining Center",
    category: "Machinery",
    image: "/gallery/vmc-machine.jpg",
  },
  {
    title: "CNC Milling Operation",
    category: "Services",
    image: "/gallery/cnc-milling.jpg",
  },
  {
    title: "Precision Mold Assembly",
    category: "Molds",
    image: "/gallery/mold-assembly.jpg",
  },
  {
    title: "High Precision Components",
    category: "Components",
    image: "/gallery/precision-component-1.jpg",
  },
  {
    title: "PET Preform Molds",
    category: "Products",
    image: "/gallery/pet-molds.jpg",
  },
  {
    title: "Blow Molds (PET & HDPE)",
    category: "Products",
    image: "/gallery/blow-molds.jpg",
  },
  {
    title: "Injection Molds Showcase",
    category: "Products",
    image: "/gallery/injection-molds.jpg",
  },
  {
    title: "Facility Overview",
    category: "Infrastructure",
    image: "/gallery/workshop-view-1.jpg",
  },
  {
    title: "Machine Shop Floor",
    category: "Infrastructure",
    image: "/gallery/workshop-view-2.jpg",
  },
  {
    title: "CNC Machine Setup",
    category: "Machinery",
    image: "/gallery/machine-setup-1.jpg",
  },
  {
    title: "VMC Component Setup",
    category: "Machinery",
    image: "/gallery/machine-setup-2.jpg",
  },
  {
    title: "Precision Tooling",
    category: "Machinery",
    image: "/gallery/machine-setup-3.jpg",
  },
  {
    title: "Workshop Interior",
    category: "Facilities",
    image: "/gallery/machine-1.jpg",
  },
  {
    title: "Milling Machine Station",
    category: "Facilities",
    image: "/gallery/machine-2.jpg",
  },
  {
    title: "Production Line",
    category: "Facilities",
    image: "/gallery/machine-3.jpg",
  },
  {
    title: "Vertical Machining Operation",
    category: "Machinery",
    image: "/gallery/machine-4.jpg",
  },
  {
    title: "CNC Lathe Section",
    category: "Machinery",
    image: "/gallery/machine-5.jpg",
  },
  {
    title: "Detailed Component Finishing",
    category: "Components",
    image: "/gallery/component-detail.jpg",
  },
  {
    title: "Complex Mold Cavity",
    category: "Molds",
    image: "/gallery/mold-part-2.jpg",
  },
  {
    title: "Engineered Precision Part",
    category: "Components",
    image: "/gallery/precision-component-2.jpg",
  },
  {
    title: "Custom Machined Base",
    category: "Components",
    image: "/gallery/precision-component-3.jpg",
  },
  {
    title: "Our Hyderabad Workshop",
    category: "Facilities",
    image: "/gallery/workshop-floor.jpg",
  },
];

const Gallery = () => {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  return (
    <section id="gallery" className="py-24 bg-white dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading 
          title="Our Gallery" 
          subtitle="Precision in Action at Our Hyderabad Workshop" 
        />
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 aspect-video cursor-pointer"
              onClick={() => setLightboxIndex(index)}
            >
              <Image 
                src={item.image} 
                alt={item.title}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-110 opacity-90 dark:opacity-80 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent dark:from-slate-950 dark:via-transparent dark:to-transparent opacity-60" />
              <div className="absolute bottom-0 left-0 p-6 w-full translate-y-2 group-hover:translate-y-0 transition-transform">
                <span className="text-blue-600 dark:text-blue-400 text-xs font-bold uppercase tracking-widest">{item.category}</span>
                <h3 className="text-white font-bold text-lg">{item.title}</h3>
              </div>
            </motion.div>
          ))}
        </div>

        <AnimatePresence>
          {lightboxIndex !== null && (
            <Lightbox 
              images={galleryItems}
              initialIndex={lightboxIndex}
              onClose={() => setLightboxIndex(null)}
            />
          )}
        </AnimatePresence>
        
        <div className="mt-12 text-center">
          <p className="text-slate-500 dark:text-gray-400 italic">
            Authentic equipment and components from UAU JIGBO TECHNICS, Hyderabad.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Gallery;
